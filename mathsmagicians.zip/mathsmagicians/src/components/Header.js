import React from 'react';
import './Header.css';

const Header = () => (
  <div>
    <h1 className="title">Math Magicians</h1>
  </div>
);

export default Header;
